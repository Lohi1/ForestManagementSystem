
  package com.cg.fms.main;
  
  import java.util.Iterator; 
  import java.util.List; 
  import java.util.Scanner;
  
  import com.cg.fms.dto.Land;
import com.cg.fms.dto.Orders;
import com.cg.fms.exceptions.DataNotFoundException; 
  import com.cg.fms.service.ILandService; 
  import com.cg.fms.service.LandService;
  
  public class LandMain 
  { 
	  static int landId; 
	  static String surveyNumber; 
	  static String ownerName; 
	  static String landArea; 
	  public static void main(String[] args) throws DataNotFoundException
	  { 
		 Scanner scanner=new Scanner(System.in);
		 ILandService service= new LandService(); 
		 while(true) 
		 { 
			 System.out.println("******************************Land Services*******************************"); 
			 System.out.println("Enter yor choice");
			 System.out.println("1.To get land details");
			 System.out.println("2.To add a new land");
			 System.out.println("3.To Update a land ");
			 System.out.println("4.To delete a land");
			 System.out.println("5.To get all land records"); 
			 System.out.println("****************************************************************************"); 
			 int choice=scanner.nextInt();
  
			  switch(choice) 
			  { 
			  /*
				 * This function will call the service layer method and service layer calls the Dao layer and return the land
				 * object which is populated by the information of the given.
				 */
			  
			  /*
				 * This function will call the service layer method and service layer calls the Dao layer and return the land
				 *  details with respect to surveynumber.
				 */
			  
			  case 1: System.out.println("Enter land id you want to get");
			  surveyNumber=scanner.next(); 
			  Land land = service.getLand(surveyNumber);
			  
			  if(surveyNumber!=null) 
			  { 
				  System.out.println(service.getLand(surveyNumber));
			 
				  } 
			  else 
			  { 
				  throw new DataNotFoundException("enter valid land Id");
			  	  }
			  
			  case 2: 
				// Reading and setting the values for the addland
				  System.out.println("Enter the land id");
				  int landId=scanner.nextInt();
				  System.out.println("enter the surveyNumber");
					String surveyNumber=scanner.next();
					System.out.println("enter the ownerName ");
					String ownername=scanner.next();
					System.out.println("enter the  landArea");
					String dlandArea=scanner.next();
					
					Land l= new Land(landId, surveyNumber, ownerName, landArea);
					if(service.addLand(l))
					{
						System.out.println("Land added succesfully");
					}
					else
					{
						throw new DataNotFoundException("Land not added");
					}
					break;
					/*
					 * This function will call the service layer method and service layer calls the Dao layer and return the land
					 * details with updated values
					 */
				
				 case 3: 
						  System.out.println("Enter the id of land whose survey number should be updated");
						  landId=scanner.nextInt();
						  System.out.println("enter the new surveyNumber");
						  surveyNumber=scanner.next(); 
						  Land updateLand =new Land(landId,surveyNumber,ownerName,landArea);
					  
						  if(service.updateLand(updateLand))
						  {
						  System.out.println("Land details are  updated succesfully"); }
						  
						  else 
						  { 
							  throw new DataNotFoundException(" land's id,surveyNumber are  not updated!");
							  } 
						  break;
						  /*
							 * This function will call the service layer method and service layer calls the Dao layer and return the 
							 * deleted land details.
							 */
						  case 4: 
						  System.out.println("Enter surveyNumber of the land whose record need to be deleted");
						  landId =scanner.nextInt(); 
						  Land removesurveyNumber =new Land();
						  if(service.removeLandDetails(removesurveyNumber.getLandId()))
						  {
						  System.out.println("land record removed successfully"); 
						  } 
						  break;
						  /*
							 * This function will call the service layer method and service layer calls the Dao layer and return the 
							 * list of all lands present in the database.
							 */
						  case 5:
						  List<Land> landrecords =service.getAllLands(); 
						  Iterator<Land> iterator=landrecords.iterator();
						  while(iterator.hasNext())
						  {
							  Land record=(Land) iterator.next(); 
							  System.out.println(record); 
						  } 
					  break; 
			  }
			}
			 
		 }
	  }
					 
				  
			
				  
		
				  
				 
