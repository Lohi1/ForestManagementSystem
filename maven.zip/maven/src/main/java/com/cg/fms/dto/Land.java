package com.cg.fms.dto;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
	@Entity
	@Table(name="Land_Details")
	public class Land
	{
		@Id	
		
		@Column(name="Land_id")
		public int landId;
		@Column(name="Survey_number")
		public String surveyNumber;
		@Column(name="Owner_name")
		public  String ownerName;
		@Column(name="Land_area")
		public String landArea;
	
		public Land() 
		{
			super();
		
		}
	public Land(String surveyNumber, String ownerName, String landArea) {
		super();
		this.surveyNumber = surveyNumber;
		this.ownerName = ownerName;
		this.landArea = landArea;
	}
	
	
	public Land(int landId, String surveyNumber, String ownerName, String landArea) {
		super();
		this.landId = landId;
		this.surveyNumber = surveyNumber;
		this.ownerName = ownerName;
		this.landArea = landArea;
	}
	
	public Land(String surveyNumber) {
		super();
		this.surveyNumber = surveyNumber;
	}
	public int getLandId() {
		return landId;
	}
	public void setLandId(int landId) {
		this.landId = landId;
	}
	public String getSurveyNumber() {
		return surveyNumber;
	}
	public void setSurveyNumber(String surveyNumber) {
		this.surveyNumber = surveyNumber;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getLandArea() {
		return landArea;
	}
	public void setLandArea(String landArea) {
		this.landArea = landArea;
	}
	
	
	@Override
	public String toString() {
		return "Land [landId=" + landId + ", surveyNumber=" + surveyNumber + ", ownerName=" + ownerName + ", landArea="
				+ landArea + "]";
	}
	
	
	
	
	
	
	
		
	}
