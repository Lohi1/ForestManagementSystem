package com.cg.fms.service;


import java.util.List;

import com.cg.fms.dao.IOrderDao;
import com.cg.fms.dao.OrderDao;
import com.cg.fms.dto.Orders;

public class OrderService implements IOrderService{
	IOrderDao dao=new OrderDao();
	//------------------------ 1. Order Details --------------------------
			/*******************************************************************************************************
			 - Function Name	:	addOrder
			 - Input Parameters	:	land object
			 - Return Type		:	order
			 - Author			:	Lohitha
			 - Creation Date	:	29/10/2020
			 - Description		:	adding order details to database calls dao method addOrder(Orders order)
			 ********************************************************************************************************/
	
	public boolean addOrder(Orders order) {
		// TODO Auto-generated method stub
		if(dao.addOrder(order)) {
			return true;
		}
		else {
			return false;
		}
	}
	//------------------------ 1. Order Details --------------------------
			/*******************************************************************************************************
			 -- Function Name	:	getOrder
			 - Input Parameters	:	String orderNumber
			 - Return Type		:	String
			 - Author			:	Lohitha
			 - Creation Date	:	29/10/2020
			 - Description		:	getting order details in database calls dao method getOrder(String orderNumber)
			 ********************************************************************************************************/
	

	@Override
	public Orders getOrder(String orderNumber) {
		return dao.getOrder(orderNumber);

	}
	//------------------------ 1. Order Details --------------------------
			/*******************************************************************************************************
			 - Function Name	:	UpdateOrder
			 - Input Parameters	:	product object
			 - Return Type		:	Order
			 - Author			:	Lohitha
			 - Creation Date	:	29/10/2020
			 - Description		:	updating order details to database calls dao method UpdateOrder(Orders order)
			 ********************************************************************************************************/

	@Override
	public boolean updateOrder(Orders order) {
		if(dao.updateOrder(order)) {
			return true;
		}
		else {
			return false;
		}
	}
	//------------------------ 1.Order Details  --------------------------
			/*******************************************************************************************************
			 - Function Name	:	deleteOrder
			 - Input Parameters	:	String orderNumber
			 - Return Type		:	String
			 - Author			:	Lohitha
			 - Creation Date	:	29/10/2020
			 - Description		:	deleting order details to database calls dao method deleteOrder(String orderNumber)
			 ********************************************************************************************************/
	@Override
	public boolean deleteOrder(String orderNumber) {
		if(dao.deleteOrder(orderNumber)) {
			return true;
		}
		else {
			return false;
		}
	}
	//------------------------ 1.Order Details--------------------------
			/*******************************************************************************************************
			 -- Function Name	:	getAllOrders
			 - Return Type		:	List<Orders>
			 - Author			:	Lohitha
			 - Creation Date	:	29/10/2020
			 - Description		:	getting all the order details in database calls dao method getAllOrders()
			 ********************************************************************************************************/

	@Override
	public List<Orders> getAllOrders() {
		return dao.getAllOrders();
	}

	
}

