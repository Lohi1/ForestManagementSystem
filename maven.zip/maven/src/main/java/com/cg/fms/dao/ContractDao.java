package com.cg.fms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.fms.dto.Contract;
import com.cg.fms.service.ContractService;
import com.cg.fms.utility.Connection;


public class ContractDao implements IContractDao {
    EntityManagerFactory factory=null;
	EntityManager manager=null;
	EntityTransaction transaction=null;
	
	public Contract getContract(String contractNumber) {
		factory=Connection.getFactory();
		manager=factory.createEntityManager();
		transaction=manager.getTransaction();
		
		Query query=manager.createQuery("select a from Contract a where a.contractNumber=?1");
		query.setParameter(1,contractNumber);
		List<Contract> contract=query.getResultList();
		return (Contract) contract;
	}
	
	public boolean addContract(Contract contract) {
		factory = Connection.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		if(contract!=null) {

		transaction.begin();
		manager.persist(contract);
		transaction.commit();
		return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean updateContract(Contract contract) {
		factory=Connection.getFactory();
		manager=factory.createEntityManager();
		transaction=manager.getTransaction();
		
		Contract contractRecord =manager.find(Contract.class, contract.contractNumber);
		if(contractRecord!=null) {
			transaction.begin();
			contractRecord.setDeliveryPlace(contract.deliveryPlace);
			transaction.commit();
			return true;
		}
		else {
			return false;
		}
	}

 public boolean deleteContract(String contractNumber) {
	 factory=Connection.getFactory();
		manager=factory.createEntityManager();
		transaction=manager.getTransaction();
		
		Contract contract=manager.find(Contract.class, contractNumber);
		
		transaction.begin();
		manager.remove(contract);
		transaction.commit();
		return true;
 }
	public List<Contract> getAllContracts(){
		factory=Connection.getFactory();
		manager=factory.createEntityManager();
		String selectQuery="SELECT a FROM Contract a";
		Query query=manager.createQuery(selectQuery);
		List<Contract> list= query.getResultList();
		return list;
	}
}
