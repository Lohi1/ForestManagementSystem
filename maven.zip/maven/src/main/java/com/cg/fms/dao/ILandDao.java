package com.cg.fms.dao;

import java.util.List;

import com.cg.fms.dto.Land;
import com.cg.fms.exceptions.DataNotFoundException;

public interface ILandDao {
	public Land getLand(String surveyNumber) throws DataNotFoundException;

	public boolean addLand(Land land);

	public boolean updateLand(Land land);

	public boolean removeLandDetails(int landId) ;
	
	public List<Land> getAllLands();

	
	

}
