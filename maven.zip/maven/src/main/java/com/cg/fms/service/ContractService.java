package com.cg.fms.service;

import com.cg.fms.dao.IContractDao;

import java.util.List;

import com.cg.fms.dao.ContractDao;
import com.cg.fms.dto.Contract;

public class ContractService implements IContractService{
	IContractDao cdao=new ContractDao();
	public Contract getContract(String contractNumber) {
		return cdao.getContract(contractNumber);
	}
	
	public boolean addContract(Contract contract) {
		//String regex="^(?=.*[a-z])(?=.*[A-Z])(?=.*\\\\d)[a-zA-Z\\\\d]{8,}";
		
			if(cdao.addContract(contract)) {
				return true;
			}
			else {
				return false;
			}
		
	}
	public boolean updateContract(Contract contract) 
	{
		//String regex="^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,}";
		if(cdao.updateContract(contract))
		{
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean deleteContract(String contractNumber) {
		return cdao.deleteContract(contractNumber);
	}
	public List<Contract> getAllContracts(){
		return cdao.getAllContracts();
	}
	
}
