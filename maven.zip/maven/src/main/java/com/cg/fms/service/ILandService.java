package com.cg.fms.service;



import java.util.List;

import com.cg.fms.dto.Land;
import com.cg.fms.exceptions.DataNotFoundException;

public interface ILandService {
	
	public Land getLand(String surveyNumber);
	public boolean addLand(Land land);
	public boolean updateLand(Land land);
	public boolean removeLandDetails(int landId);
	public List<Land> getAllLands();
	

	
	
}
