
  package com.cg.fms.service;
  
  import java.util.List;
  
  import com.cg.fms.dao.ILandDao; 
  import com.cg.fms.dao.LandDao; 
  import com.cg.fms.dto.Land;
import com.cg.fms.dto.Orders;
import com.cg.fms.exceptions.DataNotFoundException;
  
  public class LandService implements ILandService
  { 
	  ILandDao ldao=new LandDao(); 
	//------------------------ 1.Land Details --------------------------
			/*******************************************************************************************************
			 -- Function Name	:	getLand
			 - Input Parameters	:	String surveyNumber
			 - Return Type		:	String
			 - Author			:	Lohitha
			 - Creation Date	:	29/10/2020
			 - Description		:	getting land details in database calls dao method getland(String surveyNumber)
			 ********************************************************************************************************/
	  public Land getLand(String surveyNumber) throws DataNotFoundException 
	  { 
		  return ldao.getLand(surveyNumber);
	  }
	//------------------------ 1.Land Details --------------------------
		/*******************************************************************************************************
		 -- Function Name	:	addLand
		 - Input Parameters	:	Land land
		 - Return Type		:	boolean
		 - Author			:	Lohitha
		 - Creation Date	:	29/10/2020
		 - Description		:	adding land details in database calls dao method addland(Land land)
		 ********************************************************************************************************/
	  public boolean addLand(Land land) {
			// TODO Auto-generated method stub
			if(ldao.addLand(land)) {
				return true;
			}
			else {
				return false;
			}
		}
	//------------------------ 1.Land Details --------------------------
		/*******************************************************************************************************
		 -- Function Name	:	updateLand
		 - Input Parameters	:	Land land
		 - Return Type		:	boolean
		 - Author			:	Lohitha
		 - Creation Date	:	29/10/2020
		 - Description		:	updating land details in database calls dao method updateland(Land land)
		 ********************************************************************************************************/
  public boolean updateLand(Land land) 
  { 
	  
  if(ldao.updateLand(land))
  { 
	  return true; 
	  }
  else 
  { 
	  return false;
	  } 
  }
  
//------------------------ 1.Land Details --------------------------
	/*******************************************************************************************************
	 -- Function Name	:	removeLandDetails
	 - Input Parameters	:	int landId
	 - Return Type		:	String
	 - Author			:	Lohitha
	 - Creation Date	:	29/10/2020
	 - Description		:	deleting land details in database calls dao method removeLandDetails(int landId)
	 ********************************************************************************************************/
  public boolean removeLandDetails( int landId)
  {
  if(ldao.removeLandDetails(landId)) 
  { 
	  return true;
	  } 
  else 
  { 
	  return false; 
	  } 
  } 
//------------------------ 1.Land Details --------------------------
	/*******************************************************************************************************
	 -- Function Name	:	getAllLands
	 - Input Parameters	:	Land land
	 - Return Type		:	String
	 - Author			:	Lohitha
	 - Creation Date	:	29/10/2020
	 - Description		:	getting all the land details in database calls dao method getAllLands()
	 ********************************************************************************************************/
  public List<Land> getAllLands()
  { 
	  return ldao.getAllLands(); 
	  }
  
  }
 




