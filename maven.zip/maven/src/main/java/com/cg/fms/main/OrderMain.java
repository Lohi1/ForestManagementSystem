package com.cg.fms.main;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.fms.dto.Orders;
import com.cg.fms.exceptions.DataNotFoundException;
import com.cg.fms.service.IOrderService;
import com.cg.fms.service.OrderService;

public class OrderMain 
{
	static String orderNumber;
	static String deliveryPlace;
	static String deliveryDate;
	static String quantity;
	public static void main(String[] args) throws DataNotFoundException
	{
		 Scanner scanner=new Scanner(System.in);
		 
		 IOrderService service=new OrderService();
		 while(true)
		 {
			System.out.println("******************************Order Services*******************************");
			System.out.println("Enter yor choice");
			System.out.println("1.To add order details");
			System.out.println("2.To get  order details");
			System.out.println("3.To Update order details ");
			System.out.println("4.To delete order details");
			System.out.println("5.To get all order records");
			System.out.println("****************************************************************************");
			
			int ch=scanner.nextInt();
			switch(ch)
			{
			/*
			 * This function will call the service layer method and service layer calls the Dao layer and return the order
			 * object which is populated by the information of the given.
			 */
				case 1:
				{
					// Reading and setting the values for the addorder
					System.out.println("enter the orderNumber");
					String orderNumber=scanner.next();
					System.out.println("enter the delivery Place ");
					String deliveryPlace=scanner.next();
					System.out.println("enter the  delivery Date");
					String deliveryDate=scanner.next();
					System.out.println("enter the Quantity");
					String quantity=scanner.next();
					Orders o= new Orders(orderNumber, deliveryPlace, deliveryDate, quantity);
					if(service.addOrder(o))
					{
						System.out.println("Order added succesfully");
					}
					else
					{
						throw new DataNotFoundException("Order not added");
					}
					
				}
				break;
				/*
				 * This function will call the service layer method and service layer calls the Dao layer and return the order
				 *  details with respect to orderNumber.
				 */
				case 2:
				{
					System.out.println("enter the order you want to get ");
					String orderNumber=scanner.next();
					try
					{
						Orders order= service.getOrder(orderNumber);
						System.out.println(order);
						System.out.println("Order details are updated");
					}
					catch(DataNotFoundException e)
					{
						System.out.println(e.getMessage());
						
					}
				
				}
				break;
				
				/*
				 * This function will call the service layer method and service layer calls the Dao layer and return the order
				 * details with updated values
				 */
				case 3:
					System.out.println("Enter the no of order whose order number should be displayed");
					orderNumber=scanner.next();
					System.out.println("enter the new deliveryPlace");
					deliveryPlace=scanner.next();
					System.out.println("enter the new deliveryDate");
					deliveryDate=scanner.next();
					System.out.println("enter the new Quantity");
					quantity=scanner.next();
					Orders o= new Orders(orderNumber, deliveryPlace, deliveryDate, quantity);
					
					if(service.updateOrder(o))
					{
						System.out.println("order details are updated ");
					}
				
					else
					{
						throw new DataNotFoundException(" order's no,delivery place are  not updated!"); 
					}
					break;
					/*
					 * This function will call the service layer method and service layer calls the Dao layer and return the 
					 * deleted order.
					 */
				case 4:
					System.out.println("Enter the no that you want to delete:");
					String orderNumber=scanner.next();
					Orders removeorderNumber =new Orders();
					if(service.deleteOrder(removeorderNumber.getOrderNumber()))
					{
						System.out.println("order record removed successfully");
					}
					break;
					/*
					 * This function will call the service layer method and service layer calls the Dao layer and return the 
					 * list of all orders present in the database.
					 */
				case 5:
					List<Orders> list=service.getAllOrders();
					 Iterator<Orders> iterator=list.iterator();
					 while(iterator.hasNext())
					 {
						Orders record=(Orders) iterator.next();
						System.out.println(record);
					 }
					 break;
				}
				
			}
			
		}
	}

