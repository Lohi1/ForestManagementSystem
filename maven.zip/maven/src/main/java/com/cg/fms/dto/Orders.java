package com.cg.fms.dto;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="orders_data")
public class Orders 
{
	@Id
	//@GeneratedValue()
	public String orderNumber;
	public String deliveryPlace;
	public String deliveryDate;
	public String quantity;
	/*@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name="")
	private Scheduler scheduler;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name="")
	private Contract contract;
	@OneTOMany(cascade = CascadeType.ALL)
	@JoinTable(name="")
	private Customer customer;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name="")
	private Product product;
	*/
	public Orders() {
		super();
	}
	
	public Orders(String orderNumber, String deliveryPlace, String deliveryDate, String quantity) {
		super();
		this.orderNumber = orderNumber;
		this.deliveryPlace = deliveryPlace;
		this.deliveryDate = deliveryDate;
		this.quantity = quantity;
	}

	public Orders(String deliveryPlace, String deliveryDate, String quantity) {
		super();
		this.deliveryPlace = deliveryPlace;
		this.deliveryDate = deliveryDate;
		this.quantity = quantity;
	}
	

	public Orders(String orderNumber) {
		super();
		this.orderNumber = orderNumber;
	}

	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getDeliveryPlace() {
		return deliveryPlace;
	}
	public void setDeliveryPlace(String deliveryPlace) {
		this.deliveryPlace = deliveryPlace;
	}
	public String getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Order [orderNumber=" + orderNumber + ", deliveryPlace=" + deliveryPlace + ", deliveryDate="
				+ deliveryDate + ", quantity=" + quantity + "]";
	}
	
	
}

