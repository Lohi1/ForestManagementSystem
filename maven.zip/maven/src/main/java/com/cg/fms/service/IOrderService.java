package com.cg.fms.service;


import java.util.List;

import com.cg.fms.dto.Orders;

public interface IOrderService {
	public Orders getOrder(String orderNumber);

	public boolean addOrder(Orders order);

	public boolean updateOrder(Orders order);

	public boolean deleteOrder(String orderNumber);
	
	public List<Orders> getAllOrders();
	
}