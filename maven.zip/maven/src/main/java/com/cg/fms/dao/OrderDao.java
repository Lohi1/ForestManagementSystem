package com.cg.fms.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.fms.dto.Orders;
import com.cg.fms.exceptions.DataNotFoundException;

import com.cg.fms.service.OrderService;

import com.cg.fms.utility.Connection;


public class OrderDao implements IOrderDao 
{

	EntityManagerFactory factory=null;
	EntityManager manager=null;
	EntityTransaction transaction=null;
	//------------------------ 1. Order Details --------------------------
			/*******************************************************************************************************
			 - Function Name	:	addOrder(Orders order) 
			 - Input Parameters	:	Orders order
			 - Return Type		:	boolean
			 - Author			:	Lohitha
			 - Creation Date	:	28/10/2020
			 - Description		:	Adding Orders
			 ********************************************************************************************************/
	
	
	public boolean  addOrder(Orders order) 
	{
		factory = Connection.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		if(order!=null) 
		{
			transaction.begin();
			manager.persist(order);
			transaction.commit();
			return true;
		}
		else
		{
			return false;
		}
	}
	//------------------------ 1. Order Details --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getOrder(Orders order) 
	 - Input Parameters	:	Orders order
	 - Return Type		:	boolean
	 - Author			:	Lohitha
	 - Creation Date	:	28/10/2020
	 - Description		:	getting Orders
	 ********************************************************************************************************/

	public Orders getOrder(String orderNumber) 
	{
		factory = Connection.getFactory();
		manager = factory.createEntityManager();
		Orders order=manager.find(Orders.class, orderNumber);
		if(order==null)
		{
			throw new DataNotFoundException("Order is not found with given Number");
		}
		return order;
	}

	
	//------------------------ 1. Order Details --------------------------
	/*******************************************************************************************************
	 - Function Name	:	updateOrder(Orders order) 
	 - Input Parameters	:	Orders order
	 - Return Type		:	boolean
	 - Author			:	Lohitha
	 - Creation Date	:	28/10/2020
	 - Description		:	Updating Orders
	 ********************************************************************************************************/
	@Override
	public boolean updateOrder(Orders order) {
		// TODO Auto-generated method stub
		factory = Connection.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		Orders orderRecord = manager.find(Orders.class,order.orderNumber);
	
		if (orderRecord!= null)
		{
			transaction.begin();
			orderRecord.setOrderNumber(order.orderNumber);
			orderRecord.setDeliveryPlace(order.deliveryPlace);
			orderRecord.setDeliveryDate(order.deliveryDate);
			transaction.commit();
			return true;
		}
		else
		{
			return false;
		}
	}
	//------------------------ 1. Order Details --------------------------
		/*******************************************************************************************************
		 - Function Name	:	deleteOrder(Orders order) 
		 - Input Parameters	:	Orders order
		 - Return Type		:	boolean
		 - Author			:	Lohitha
		 - Creation Date	:	28/10/2020
		 - Description		:	Deleting Orders
		 ********************************************************************************************************/
	public boolean  deleteOrder(String orderNumber) 
	{
		factory=Connection.getFactory();
		manager= factory.createEntityManager();
		transaction = manager.getTransaction();
		Orders order=manager.find(Orders.class,orderNumber);
		 if(order==null)
		 {
			 throw new DataNotFoundException("Order is not found with the given Number");
		 }
		 else
		 {
			 transaction.begin();
			 manager.remove(order);
			 transaction.commit();
		 }
		return true;
	}
	//------------------------ 1. Order Details --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getAllOrders() 
	 - Input Parameters	:	No
	 - Return Type		:	List<Orders>
	 - Author			:	Lohitha
	 - Creation Date	:	28/10/2020
	 - Description		:	Getting all the Orders
	 ********************************************************************************************************/
	
	public List<Orders> getAllOrders() {
		factory = Connection.getFactory();
		manager = factory.createEntityManager();
		String selectQuery ="Select e from Orders e ";
		Query query=manager.createQuery(selectQuery);
		List<Orders> list=query.getResultList();
		
		return list;
	}

	
	

	}

