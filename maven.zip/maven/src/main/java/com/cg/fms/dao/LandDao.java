
  package com.cg.fms.dao;
  
  import java.util.List;
  
  import javax.persistence.EntityManager;
  import javax.persistence.EntityManagerFactory;
  import javax.persistence.EntityTransaction; 
  import javax.persistence.Persistence;
  import javax.persistence.Query;
  
  import com.cg.fms.dto.Land;
import com.cg.fms.dto.Orders;
import com.cg.fms.exceptions.DataNotFoundException;
  import com.cg.fms.service.LandService; 
  import com.cg.fms.utility.Connection;
  
  
  public class LandDao implements ILandDao
  { 
	  EntityManagerFactory factory=null;
      EntityManager manager=null; EntityTransaction transaction=null;
    //------------------------ 1. Land Details --------------------------
  	/*******************************************************************************************************
  	 - Function Name	:	getLand(surveyNumber) 
  	 - Input Parameters	:	String surveyNumber
  	 - Return Type		:	land
  	 - Author			:	Lohitha
  	 - Creation Date	:	28/10/2020
  	 - Description		:	Getting Land
  	 ********************************************************************************************************/
    
  
  public Land getLand(String surveyNumber) 
  {
	   factory=Connection.getFactory();
       manager=factory.createEntityManager(); transaction=manager.getTransaction();
       Query query=manager.createQuery("select a from Land a where a.surveyNumber=?1");
       query.setParameter(1,surveyNumber); 
       List<Land> land=query.getResultList();
       return (Land) land;
  
  }
//------------------------ 1. Land Details --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addLand(Land land) 
	 - Input Parameters	:	Land  land
	 - Return Type		:	boolean
	 - Author			:	Lohitha
	 - Creation Date	:	28/10/2020
	 - Description		:	Adding Land
	 ********************************************************************************************************/
  
  
  
  public boolean  addLand(Land land) 
	{
		factory = Connection.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		if(land!=null) 
		{
			transaction.begin();
			manager.persist(land);
			transaction.commit();
			return true;
		}
		else
		{
			return false;
		}
	}
//------------------------ 1. Land Details --------------------------
	/*******************************************************************************************************
	 - Function Name	:	updateLand(Land land) 
	 - Input Parameters	:	Land  land
	 - Return Type		:	boolean
	 - Author			:	Lohitha
	 - Creation Date	:	28/10/2020
	 - Description		:	update Land
	 ********************************************************************************************************/
  
  
  public boolean updateLand(Land land) 
  { 
		  factory=Connection.getFactory();
	  
		  manager=factory.createEntityManager(); 
		  transaction=manager.getTransaction();
	  
	      Land landRecord =manager.find(Land.class, land.landId); 
		  if(landRecord!=null)
		  { 
			  transaction.begin(); 
			  landRecord.setOwnerName(land.ownerName);
		  
		  transaction.commit();
		  return true; 
		  } 
		  else 
		  { 
			  return false; 
			  } 
	  	}
//------------------------ 1. Land Details --------------------------
	/*******************************************************************************************************
	 - Function Name	:	removeLandDetails(Land land) 
	 - Input Parameters	:	Land  land
	 - Return Type		:	boolean
	 - Author			:	Lohitha
	 - Creation Date	:	28/10/2020
	 - Description		:	removeLandDetails Land
	 ********************************************************************************************************/
  
  
  
	  public boolean removeLandDetails(int landId)
	  {
	  factory=Connection.getFactory();
	  manager=factory.createEntityManager();
	  transaction=manager.getTransaction();
	  
	  Land land=manager.find(Land.class, landId);
	  
	  transaction.begin();
	  manager.remove(land); 
	  transaction.commit(); 
	  return true;
	  
	  }
	//------------------------ 1. Land Details --------------------------
		/*******************************************************************************************************
		 - Function Name	:	getAllLand(Land land) 
		 - Input Parameters	:	Land  land
		 - Return Type		:	boolean
		 - Author			:	Lohitha
		 - Creation Date	:	28/10/2020
		 - Description		:	Getting All Land Details
		 ********************************************************************************************************/
	  
	  public List<Land> getAllLands()
	  { 
		  factory=Connection.getFactory();
	  
	  manager=factory.createEntityManager();
	  String selectQuery="SELECT a FROM Land a"; 
	  Query query=manager.createQuery(selectQuery); List<Land> list=
	  query.getResultList(); 
	  System.out.println(list);
	  return list;
	  }



	
	  }
	 
