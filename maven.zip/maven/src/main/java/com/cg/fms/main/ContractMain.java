package com.cg.fms.main;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.fms.dao.IContractDao;
import com.cg.fms.dao.ContractDao;
import com.cg.fms.dto.Contract;
import com.cg.fms.exceptions.DataNotFoundException;
import com.cg.fms.service.IContractService;
import com.cg.fms.service.ContractService;
public class ContractMain {
	static String  contractNumber;
	static String deliveryPlace;
	static String deliveryDate;
	static String quantity;
	 public static void main(String[] args) throws DataNotFoundException  {
		 Scanner scanner=new Scanner(System.in);
		 
		 IContractService service= new ContractService();
		while(true)
		{
			System.out.println("******************************Contract Services*******************************");
			System.out.println("Enter yor choice");
			System.out.println("1.To get contract details");
			System.out.println("2.To add a new contract");
			System.out.println("3.To Update an contract ");
			System.out.println("4.To delete a contract");
			System.out.println("5.To get all contract records");
			System.out.println("****************************************************************************");
			int choice=scanner.nextInt();
			
			switch(choice)
			{
				case 1:
					System.out.println("Enter contract Number");
					 contractNumber=scanner.next();
					if(contractNumber==null)
					{
						throw new DataNotFoundException("enter valid order Number");
					}
					else
					{
						System.out.println(service.getContract(deliveryPlace));
					}
					break;
			case 2: System.out.println("Enter delivey place");
					deliveryPlace=scanner.next();
					System.out.println("enter the deliveyDate ");
					deliveryDate=scanner.next();
					System.out.println("Enter the quantity");
					quantity=scanner.next();
					Contract contract=new Contract(deliveryPlace,deliveryDate,quantity);
					if(service.addContract(contract))
					{
						System.out.println("Contract added succesfully");
					}
					else
					{
						throw new DataNotFoundException("Contract not added, your details are wrong please verify once");
					}
					break;
			case 3: System.out.println("Enter the contract whose contract number should be updated");
			         contractNumber =scanner.next();
					System.out.println("enter the new quantity");
					quantity=scanner.next();
					Contract updateContract =new Contract(contractNumber,deliveryPlace,deliveryDate,quantity);
					
					if(service.updateContract(updateContract))
					{
						System.out.println("Contract details are  updated succesfully");
					}
				
					else
					{
						throw new DataNotFoundException(" Contract Number is  not updated!"); 
					}
					break;
			case 4: System.out.println("Enter Contract Number of the land whose record need to be deleted");
					String ContractNumber =scanner.next();
					Contract removecontractNumber =new Contract(ContractNumber);
					if(service.deleteContract(removecontractNumber.getContractNumber()))
					{
						System.out.println("Contract removed successfully");
					}
					break;
			case 5:	 List<Contract> Contractrecords =service.getAllContracts();
					 Iterator<Contract> iterator=Contractrecords.iterator();
					 while(iterator.hasNext())
					 {
						 Contract record=(Contract) iterator.next();
						System.out.println(record);
					 }
					 break;	
			}
		}
		
	}

}
