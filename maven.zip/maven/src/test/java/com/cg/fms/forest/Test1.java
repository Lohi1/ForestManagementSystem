package com.cg.fms.forest;

static ILandDao dao;
@BeforeClass
public static void Test1()
{
	System.out.println("Inside before class");
	dao=new LandDao();
}
@Test
public void testAddLand()
{
	//assertEquals
	Land landRecord1=new Land("Shiva","Shiva85");
	Assertions.assertEquals(true, dao.addLand(landRecord1)); 
	//assertNotEquals

	Land landRecord3=new Land("Shiva","");
	Assertions.assertNotEquals(true ,dao.addOrder(landRecord3));
	Land landRecord4=new Land("Vishnu","vishnu85");
	Assertions.assertNotEquals(true ,dao.addLand(landRecord4));
	Land landRecord5=new Land("Vishnu","Vishnu");
	Assertions.assertNotEquals(true ,dao.addScheduler(landRecord5));
	Orders landRecord6=new Orders("Vishnu","Vishnu@#");
	Assertions.assertNotEquals(true ,dao.addOrder(landRecord6));
}
@Test
public void testupdateOrder()
{
	Land landRecord1=new Land("lohitha","lohitha777");
		if(dao.addLand(landRecord1))
		{
			landRecord1.setSurveyNumber("lohitha171");
			if(dao.updateOrders(landRecord1))
			{
				Assertions.assertEquals("lohitha171", landRecord1.getSurveyNumber());
				Assertions.assertNotEquals(" ",landRecord1.getSurveyNumber());
			}
		}
		
}
@Test
public void testremoveLandDetails()
{
	String landId = "11";
	if(dao.deleteLand(surveyNumber))
			{
				Assertions.assertNotNull(surveyNumber);
				Assertions.assertNotEquals(true, dao.Land(surveyNumber));
				
			}
	
}
@Test
public void testGetAllLands()
{
	List<Land> list=new ArrayList<Land>();
	Land land1=new Land("Sanju","Sanjana456");
	Land land2=new Land("pavitra","Pavitra74");
	if(dao.addLand(land1) && dao.addLand(land2))
	{
		list.add(land1);
		list.add(land2);
	}
	Assertions.assertNotNull(land1);
	Assertions.assertNotNull(land2);
	Assertions.assertNotEquals(list, dao.getAllLands());
}