package com.cg.fms.forest;

static IOrderDao dao;
@BeforeClass
public static void Test()
{
	System.out.println("Inside before class");
	dao=new OrderDao();
}
@Test
public void testAddSchedulers()
{
	//assertEquals
	Orders orderRecord1=new Orders("Shiva","Shiva85");
	Assertions.assertEquals(true, dao.addOrder(orderRecord1)); 
	//assertNotEquals

	Orders orderRecord3=new Orders("Shiva","");
	Assertions.assertNotEquals(true ,dao.addOrder(orderRecord3));
	Orders orderRecord4=new Order("Vishnu","vishnu85");
	Assertions.assertNotEquals(true ,dao.addOrder(orderRecord4));
	Orders OrdersRecord5=new Orders("Vishnu","Vishnu");
	Assertions.assertNotEquals(true ,dao.addScheduler(orderRecord5));
	Orders orderRecord6=new Orders("Vishnu","Vishnu@#");
	Assertions.assertNotEquals(true ,dao.addOrder(orderRecord6));
}
@Test
public void testupdateOrder()
{
	Orders orderRecord1=new Orders("lohitha","lohitha777");
		if(dao.addOrder(orderRecord1))
		{
			orderRecord1.setOrderNumber("lohitha171");
			if(dao.updateOrders(orderRecord1))
			{
				Assertions.assertEquals("lohitha171", orderRecord1.getOrderNumber());
				Assertions.assertNotEquals(" ",orderRecord1.getOrderNumber());
			}
		}
		
}
@Test
public void testdeleteOrder()
{
	String orderId = "11";
	if(dao.deleteOrder(orderNumber))
			{
				Assertions.assertNotNull(orderNumber);
				Assertions.assertNotEquals(true, dao.Orders(orderNumber));
				
			}
	
}
@Test
public void testGetAllOrders()
{
	List<Orders> list=new ArrayList<Orders>();
	Orders order1=new Orders("Sanju","Sanjana456");
	Orders order2=new Orders("pavitra","Pavitra74");
	if(dao.addOrder(order1) && dao.addOrder(order2))
	{
		list.add(order1);
		list.add(order2);
	}
	Assertions.assertNotNull(order1);
	Assertions.assertNotNull(order2);
	Assertions.assertNotEquals(list, dao.getAllOrders());
}
